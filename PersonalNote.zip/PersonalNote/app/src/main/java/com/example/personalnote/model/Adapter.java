package com.example.personalnote.model;

public class Adapter {
}
